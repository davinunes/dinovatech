-- Backup do Banco de Dados [Digital Inovation Tecnologia] - Gerado em 2026-10-30 05:25:54


CREATE TABLE `Agendamentos` (
  `id_agendamento` int NOT NULL AUTO_INCREMENT,
  `id_vet` int DEFAULT NULL,
  `id_cliente` int DEFAULT NULL,
  `id_pet` int DEFAULT NULL,
  `titulo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `data_inicio` datetime NOT NULL,
  `data_fim` datetime NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Agendado',
  `google_event_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_event_id_cliente` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ID do Evento na Agenda Google do Cliente',
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tipo_agenda` enum('clinica','banho_tosa') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'clinica',
  `id_cliente_pacote` int DEFAULT NULL,
  `id_servico` int DEFAULT NULL,
  PRIMARY KEY (`id_agendamento`),
  KEY `id_vet` (`id_vet`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_pet` (`id_pet`),
  CONSTRAINT `Agendamentos_ibfk_1` FOREIGN KEY (`id_vet`) REFERENCES `Veterinarios` (`id_vet`) ON DELETE CASCADE,
  CONSTRAINT `Agendamentos_ibfk_2` FOREIGN KEY (`id_cliente`) REFERENCES `Clientes` (`id_cliente`) ON DELETE SET NULL,
  CONSTRAINT `Agendamentos_ibfk_3` FOREIGN KEY (`id_pet`) REFERENCES `Pets` (`id_pet`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Arquivos` (
  `id_arquivo` int NOT NULL AUTO_INCREMENT,
  `nome_original` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url_publica` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `tamanho_bytes` int DEFAULT NULL,
  `tipo_mime` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_upload` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_arquivo`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `AtendimentoArquivos` (
  `id_vinculo` int NOT NULL AUTO_INCREMENT,
  `id_atendimento` int NOT NULL,
  `id_arquivo` int NOT NULL,
  PRIMARY KEY (`id_vinculo`),
  KEY `id_atendimento` (`id_atendimento`),
  KEY `id_arquivo` (`id_arquivo`),
  CONSTRAINT `AtendimentoArquivos_ibfk_1` FOREIGN KEY (`id_atendimento`) REFERENCES `Atendimentos` (`id_atendimento`) ON DELETE CASCADE,
  CONSTRAINT `AtendimentoArquivos_ibfk_2` FOREIGN KEY (`id_arquivo`) REFERENCES `Arquivos` (`id_arquivo`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Atendimentos` (
  `id_atendimento` int NOT NULL AUTO_INCREMENT,
  `id_pet` int NOT NULL,
  `id_vet` int NOT NULL,
  `data_atendimento` datetime DEFAULT CURRENT_TIMESTAMP,
  `queixa_principal` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `anamnese` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `exame_fisico` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `diagnostico` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `conduta_tratamento` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `id_agendamento` int DEFAULT NULL,
  `peso` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id_atendimento`),
  KEY `id_pet` (`id_pet`),
  KEY `id_vet` (`id_vet`),
  KEY `fk_atendimento_agenda` (`id_agendamento`),
  CONSTRAINT `fk_atendimento_agenda` FOREIGN KEY (`id_agendamento`) REFERENCES `Agendamentos` (`id_agendamento`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `BanhoCheckinFotos` (
  `id_foto` int NOT NULL AUTO_INCREMENT,
  `id_fila` int NOT NULL,
  `id_pet` int DEFAULT NULL,
  `foto_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_foto`),
  KEY `id_fila` (`id_fila`),
  CONSTRAINT `BanhoCheckinFotos_ibfk_1` FOREIGN KEY (`id_fila`) REFERENCES `BanhoProducaoFila` (`id_fila`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `BanhoProducaoFila` (
  `id_fila` int NOT NULL AUTO_INCREMENT,
  `id_agendamento` int DEFAULT NULL,
  `id_pet` int NOT NULL,
  `id_colaborador` int DEFAULT NULL,
  `etapa` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aguardando',
  `horario_entrada` datetime DEFAULT CURRENT_TIMESTAMP,
  `horario_inicio` datetime DEFAULT NULL,
  `horario_fim` datetime DEFAULT NULL,
  `horario_saida` datetime DEFAULT NULL,
  `observacoes_estetica` text COLLATE utf8mb4_unicode_ci,
  `ordem` int DEFAULT '0',
  PRIMARY KEY (`id_fila`),
  KEY `id_agendamento` (`id_agendamento`),
  KEY `id_pet` (`id_pet`),
  KEY `id_colaborador` (`id_colaborador`),
  CONSTRAINT `BanhoProducaoFila_ibfk_1` FOREIGN KEY (`id_agendamento`) REFERENCES `Agendamentos` (`id_agendamento`) ON DELETE SET NULL,
  CONSTRAINT `BanhoProducaoFila_ibfk_2` FOREIGN KEY (`id_pet`) REFERENCES `Pets` (`id_pet`) ON DELETE CASCADE,
  CONSTRAINT `BanhoProducaoFila_ibfk_3` FOREIGN KEY (`id_colaborador`) REFERENCES `Veterinarios` (`id_vet`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `CarteiraVacinas` (
  `id_carteira` int NOT NULL AUTO_INCREMENT,
  `id_pet` int NOT NULL,
  `id_vacina` int NOT NULL,
  `id_vet` int DEFAULT NULL,
  `data_aplicacao` date NOT NULL,
  `data_vencimento` date DEFAULT NULL,
  `lote` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_carteira`),
  KEY `id_pet` (`id_pet`),
  KEY `id_vacina` (`id_vacina`),
  CONSTRAINT `CarteiraVacinas_ibfk_1` FOREIGN KEY (`id_pet`) REFERENCES `Pets` (`id_pet`),
  CONSTRAINT `CarteiraVacinas_ibfk_2` FOREIGN KEY (`id_vacina`) REFERENCES `Vacinas` (`id_vacina`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `CentrosCusto` (
  `id_centro_custo` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cor` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '#0284c7',
  `ativo` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_centro_custo`),
  UNIQUE KEY `uniq_centrocusto_nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `ClientePacoteConsumo` (
  `id_consumo` int NOT NULL AUTO_INCREMENT,
  `id_cliente_pacote` int NOT NULL,
  `id_servico` int NOT NULL,
  `id_pet` int NOT NULL,
  `id_agendamento` int DEFAULT NULL,
  `data_consumo` datetime DEFAULT CURRENT_TIMESTAMP,
  `observacao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_consumo`),
  KEY `id_cliente_pacote` (`id_cliente_pacote`),
  KEY `id_servico` (`id_servico`),
  KEY `id_pet` (`id_pet`),
  KEY `id_agendamento` (`id_agendamento`),
  CONSTRAINT `ClientePacoteConsumo_ibfk_1` FOREIGN KEY (`id_cliente_pacote`) REFERENCES `ClientePacotes` (`id_cliente_pacote`) ON DELETE CASCADE,
  CONSTRAINT `ClientePacoteConsumo_ibfk_2` FOREIGN KEY (`id_servico`) REFERENCES `Servicos` (`id_servico`) ON DELETE CASCADE,
  CONSTRAINT `ClientePacoteConsumo_ibfk_3` FOREIGN KEY (`id_pet`) REFERENCES `Pets` (`id_pet`) ON DELETE CASCADE,
  CONSTRAINT `ClientePacoteConsumo_ibfk_4` FOREIGN KEY (`id_agendamento`) REFERENCES `Agendamentos` (`id_agendamento`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `ClientePacoteSaldos` (
  `id_saldo` int NOT NULL AUTO_INCREMENT,
  `id_cliente_pacote` int NOT NULL,
  `id_servico` int NOT NULL,
  `qtd_total` int NOT NULL DEFAULT '1',
  `qtd_utilizada` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_saldo`),
  KEY `id_cliente_pacote` (`id_cliente_pacote`),
  KEY `id_servico` (`id_servico`),
  CONSTRAINT `ClientePacoteSaldos_ibfk_1` FOREIGN KEY (`id_cliente_pacote`) REFERENCES `ClientePacotes` (`id_cliente_pacote`) ON DELETE CASCADE,
  CONSTRAINT `ClientePacoteSaldos_ibfk_2` FOREIGN KEY (`id_servico`) REFERENCES `Servicos` (`id_servico`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `ClientePacotes` (
  `id_cliente_pacote` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int NOT NULL,
  `id_pacote` int NOT NULL,
  `id_pet` int DEFAULT NULL,
  `id_recorrencia` int DEFAULT NULL,
  `data_aquisicao` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` enum('ativo','esgotado','cancelado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ativo',
  PRIMARY KEY (`id_cliente_pacote`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_pacote` (`id_pacote`),
  KEY `id_recorrencia` (`id_recorrencia`),
  CONSTRAINT `ClientePacotes_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `Clientes` (`id_cliente`) ON DELETE CASCADE,
  CONSTRAINT `ClientePacotes_ibfk_2` FOREIGN KEY (`id_pacote`) REFERENCES `Pacotes` (`id_pacote`) ON DELETE CASCADE,
  CONSTRAINT `ClientePacotes_ibfk_3` FOREIGN KEY (`id_recorrencia`) REFERENCES `Recorrencias` (`id_recorrencia`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Clientes` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cpf_cnpj` varchar(18) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inscricao_municipal` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inscricao_estadual` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT '1',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endereco` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_municipio` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `google_calendar_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'URL pública da foto de perfil do cliente no Oracle Object Storage',
  PRIMARY KEY (`id_cliente`),
  UNIQUE KEY `cpf_cnpj` (`cpf_cnpj`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `ConfiguracoesEmissor` (
  `id_config` int NOT NULL AUTO_INCREMENT,
  `razao_social` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_fantasia` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cnpj` varchar(18) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `inscricao_municipal` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `inscricao_estadual` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `camino_certificado_pfx` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_municipio` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '5300108',
  `regime_tributario` enum('simples','lucro_presumido','lucro_real') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'simples',
  `optante_simples` tinyint(1) DEFAULT '1',
  `modulo_fiscal_ativo` tinyint(1) NOT NULL DEFAULT '0',
  `nfse_provider` enum('legacy','nacional') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'legacy',
  `caminho_certificado` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `certificado_pfx_base64` longtext COLLATE utf8mb4_unicode_ci,
  `senha_certificado` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ambiente_padrao` enum('homologacao','producao') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'homologacao',
  `ultimo_rps_homologacao` int DEFAULT '0',
  `ultimo_dps_homologacao` int NOT NULL DEFAULT '0',
  `ultimo_rps_producao` int DEFAULT '0',
  `ultimo_dps_producao` int NOT NULL DEFAULT '0',
  `serie_rps` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '8',
  `serie_dps` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `endereco` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complemento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bairro` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_inter_client_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_inter_client_secret` text COLLATE utf8mb4_unicode_ci,
  `api_oracle_user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_oracle_password` text COLLATE utf8mb4_unicode_ci,
  `api_inter_chave_pix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_inter_conta_corrente` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_oracle_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_inter_cert_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_inter_cert_base64` longtext COLLATE utf8mb4_unicode_ci,
  `api_inter_key_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_inter_key_base64` longtext COLLATE utf8mb4_unicode_ci,
  `api_inter_ca_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_inter_ca_base64` longtext COLLATE utf8mb4_unicode_ci,
  `logo_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_service_account_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'Conteúdo JSON da Service Account (Criptografado)',
  `permitir_cadastro_sem_cpf` tinyint(1) DEFAULT '0',
  `landing_page_theme` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `landing_page_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `google_oauth_client_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_oauth_client_secret` text COLLATE utf8mb4_unicode_ci,
  `google_oauth_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_oauth_refresh_token` text COLLATE utf8mb4_unicode_ci,
  `email_fatura_template_id` int DEFAULT NULL,
  `contadev_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contadev_token` text COLLATE utf8mb4_unicode_ci,
  `contadev_user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contadev_cnpj_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contadev_company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contadev_user_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contadev_ativo` tinyint(1) DEFAULT '0',
  `contadev_password` text COLLATE utf8mb4_unicode_ci,
  `banho_checkin_foto_ativo` tinyint(1) NOT NULL DEFAULT '0',
  `banho_capacidade_simultanea` int NOT NULL DEFAULT '2',
  `ssh_host` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '172.17.0.1',
  `ssh_port` int DEFAULT '22',
  `ssh_user` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'root',
  `ssh_workdir` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '/var/www/html',
  `ssh_key_pem` text COLLATE utf8mb4_unicode_ci,
  `infinitepay_ativo` tinyint DEFAULT '0',
  `infinitepay_handle` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infinitepay_usar_webhook` tinyint DEFAULT '1',
  `infinitepay_usar_redirect` tinyint DEFAULT '1',
  `infinitepay_detalhar_itens` tinyint DEFAULT '1',
  `infinitepay_enviar_cliente` tinyint DEFAULT '1',
  `infinitepay_enviar_endereco` tinyint DEFAULT '1',
  `api_inter_ativo` tinyint DEFAULT '1',
  `api_oracle_ativo` tinyint DEFAULT '1',
  `google_calendar_ativo` tinyint DEFAULT '1',
  `google_gmail_ativo` tinyint DEFAULT '1',
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `CronLogs` (
  `id_cron_log` int NOT NULL AUTO_INCREMENT,
  `data_execucao` datetime DEFAULT CURRENT_TIMESTAMP,
  `tipo_tarefa` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'faturas_recorrencias',
  `status` enum('sucesso','erro','aviso') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sucesso',
  `faturas_geradas` int DEFAULT '0',
  `valor_total_gerado` decimal(10,2) DEFAULT '0.00',
  `detalhes_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `origem` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'cron',
  PRIMARY KEY (`id_cron_log`),
  KEY `idx_data_execucao` (`data_execucao`),
  KEY `idx_tipo_tarefa` (`tipo_tarefa`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `DespesaArquivos` (
  `id_vinculo` int NOT NULL AUTO_INCREMENT,
  `id_despesa` int NOT NULL,
  `id_arquivo` int NOT NULL,
  `tipo_documento` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Outro',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_vinculo`),
  KEY `idx_despesa_anexo` (`id_despesa`),
  KEY `idx_arquivo_anexo` (`id_arquivo`),
  CONSTRAINT `DespesaArquivos_ibfk_1` FOREIGN KEY (`id_despesa`) REFERENCES `Despesas` (`id_despesa`) ON DELETE CASCADE,
  CONSTRAINT `DespesaArquivos_ibfk_2` FOREIGN KEY (`id_arquivo`) REFERENCES `Arquivos` (`id_arquivo`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Despesas` (
  `id_despesa` int NOT NULL AUTO_INCREMENT,
  `id_fornecedor` int NOT NULL,
  `id_centro_custo` int DEFAULT NULL,
  `descricao` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('avulsa','parcelada','recorrente') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'avulsa',
  `status` enum('Em Aberto','Liquidada','Cancelada') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Em Aberto',
  `data_competencia` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_vencimento` date NOT NULL,
  `data_pagamento` datetime DEFAULT NULL,
  `forma_pagamento` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL DEFAULT '0.00',
  `valor_pago` decimal(10,2) NOT NULL DEFAULT '0.00',
  `numero_documento` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `id_despesa_pai` int DEFAULT NULL,
  `parcela_atual` int DEFAULT '1',
  `total_parcelas` int DEFAULT '1',
  `recorrencia_ativa` tinyint(1) DEFAULT '0',
  `dia_vencimento_recorrencia` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_despesa`),
  KEY `idx_despesa_fornecedor` (`id_fornecedor`),
  KEY `idx_despesa_centro_custo` (`id_centro_custo`),
  KEY `idx_despesa_competencia` (`data_competencia`),
  KEY `idx_despesa_vencimento` (`data_vencimento`),
  KEY `idx_despesa_status` (`status`),
  KEY `idx_despesa_pai` (`id_despesa_pai`),
  CONSTRAINT `Despesas_ibfk_1` FOREIGN KEY (`id_fornecedor`) REFERENCES `Fornecedores` (`id_fornecedor`),
  CONSTRAINT `Despesas_ibfk_2` FOREIGN KEY (`id_centro_custo`) REFERENCES `CentrosCusto` (`id_centro_custo`) ON DELETE SET NULL,
  CONSTRAINT `Despesas_ibfk_3` FOREIGN KEY (`id_despesa_pai`) REFERENCES `Despesas` (`id_despesa`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `DocumentosEmitidos` (
  `id_documento_emitido` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int DEFAULT NULL,
  `id_pet` int DEFAULT NULL,
  `id_atendimento` int DEFAULT NULL,
  `id_recorrencia` int DEFAULT NULL,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conteudo_html` longtext COLLATE utf8mb4_unicode_ci,
  `texto_personalizado` text COLLATE utf8mb4_unicode_ci,
  `data_emissao` datetime DEFAULT NULL,
  `usuario_emissor` int DEFAULT NULL,
  PRIMARY KEY (`id_documento_emitido`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `DocumentosEmitidos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `Clientes` (`id_cliente`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `FaturaArquivos` (
  `id_vinculo` int NOT NULL AUTO_INCREMENT,
  `id_fatura` int NOT NULL,
  `id_arquivo` int NOT NULL,
  PRIMARY KEY (`id_vinculo`),
  KEY `id_fatura` (`id_fatura`),
  KEY `id_arquivo` (`id_arquivo`),
  CONSTRAINT `FaturaArquivos_ibfk_1` FOREIGN KEY (`id_fatura`) REFERENCES `Faturas` (`id_fatura`) ON DELETE CASCADE,
  CONSTRAINT `FaturaArquivos_ibfk_2` FOREIGN KEY (`id_arquivo`) REFERENCES `Arquivos` (`id_arquivo`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Faturas` (
  `id_fatura` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int NOT NULL,
  `data_emissao` date NOT NULL,
  `data_vencimento` date NOT NULL,
  `valor_total_fatura` decimal(10,2) DEFAULT '0.00',
  `desconto_valor` decimal(10,2) DEFAULT '0.00',
  `desconto_tipo` enum('percentual','fixo') COLLATE utf8mb4_unicode_ci DEFAULT 'percentual',
  `permitir_pagamento_parcial` tinyint(1) DEFAULT '0',
  `status` enum('Em Aberto','Liquidada','Atrasada','Cancelada') COLLATE utf8mb4_unicode_ci DEFAULT 'Em Aberto',
  `possui_nfse` tinyint(1) DEFAULT '0',
  `data_emissao_nfse` datetime DEFAULT NULL COMMENT 'Data/hora de emissão da NFSe',
  `token_acesso` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infinitepay_checkout_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infinitepay_slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infinitepay_nsu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_fatura`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `Faturas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `Clientes` (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Fornecedores` (
  `id_fornecedor` int NOT NULL AUTO_INCREMENT,
  `razao_social` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_fantasia` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf_cnpj` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contato_responsavel` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ativo` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_fornecedor`),
  KEY `idx_fornecedor_nome` (`razao_social`,`nome_fantasia`),
  KEY `idx_fornecedor_doc` (`cpf_cnpj`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `GoogleSyncLogs` (
  `id_log` int NOT NULL AUTO_INCREMENT,
  `data_hora` datetime DEFAULT CURRENT_TIMESTAMP,
  `id_agendamento` int DEFAULT NULL,
  `calendar_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_operacao` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'create, update, delete, test, list',
  `status` enum('sucesso','erro','aviso') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sucesso',
  `http_code` int DEFAULT NULL,
  `mensagem` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload_resumo` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_log`),
  KEY `idx_id_agendamento` (`id_agendamento`),
  KEY `idx_calendar_id` (`calendar_id`),
  KEY `idx_data_hora` (`data_hora`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `InternacaoDias` (
  `id_dia` int NOT NULL AUTO_INCREMENT,
  `id_internacao` int NOT NULL,
  `data_dia` date NOT NULL,
  `soro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `volume` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frequencia` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_dia`),
  KEY `id_internacao` (`id_internacao`),
  KEY `data_dia` (`data_dia`),
  CONSTRAINT `InternacaoDias_ibfk_1` FOREIGN KEY (`id_internacao`) REFERENCES `Internacoes` (`id_internacao`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `InternacaoMedicacoes` (
  `id_medicacao` int NOT NULL AUTO_INCREMENT,
  `id_dia` int NOT NULL,
  `medicacao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dose` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `via` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `horarios` text COLLATE utf8mb4_unicode_ci,
  `ordem` int DEFAULT '0',
  PRIMARY KEY (`id_medicacao`),
  KEY `id_dia` (`id_dia`),
  CONSTRAINT `InternacaoMedicacoes_ibfk_1` FOREIGN KEY (`id_dia`) REFERENCES `InternacaoDias` (`id_dia`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Internacoes` (
  `id_internacao` int NOT NULL AUTO_INCREMENT,
  `id_pet` int NOT NULL,
  `id_vet` int DEFAULT NULL,
  `data_internacao` datetime NOT NULL,
  `data_alta` datetime DEFAULT NULL,
  `suspeita_clinica` text COLLATE utf8mb4_unicode_ci,
  `status` enum('internado','alta','obito','cancelado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'internado',
  `observacoes` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_internacao`),
  KEY `id_pet` (`id_pet`),
  KEY `id_vet` (`id_vet`),
  CONSTRAINT `Internacoes_ibfk_1` FOREIGN KEY (`id_pet`) REFERENCES `Pets` (`id_pet`) ON DELETE CASCADE,
  CONSTRAINT `Internacoes_ibfk_2` FOREIGN KEY (`id_vet`) REFERENCES `Veterinarios` (`id_vet`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `ItensFatura` (
  `id_item_fatura` int NOT NULL AUTO_INCREMENT,
  `id_fatura` int NOT NULL,
  `id_servico` int NOT NULL,
  `quantidade` int NOT NULL,
  `valor_unitario` decimal(10,2) NOT NULL,
  `tag` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `id_recorrencia` int DEFAULT NULL,
  PRIMARY KEY (`id_item_fatura`),
  KEY `id_fatura` (`id_fatura`),
  KEY `id_servico` (`id_servico`),
  KEY `fk_itensfatura_recorrencia` (`id_recorrencia`),
  CONSTRAINT `fk_itensfatura_recorrencia` FOREIGN KEY (`id_recorrencia`) REFERENCES `Recorrencias` (`id_recorrencia`),
  CONSTRAINT `ItensFatura_ibfk_1` FOREIGN KEY (`id_fatura`) REFERENCES `Faturas` (`id_fatura`) ON DELETE CASCADE,
  CONSTRAINT `ItensFatura_ibfk_2` FOREIGN KEY (`id_servico`) REFERENCES `Servicos` (`id_servico`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `ItensReceita` (
  `id_item_receita` int NOT NULL AUTO_INCREMENT,
  `id_receita` int NOT NULL,
  `nome_medicamento` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantidade` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uso` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Oral, Tópico, etc',
  `categoria` enum('Veterinaria','Humana','Manipulado') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Veterinaria',
  `posologia` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_item_receita`),
  KEY `id_receita` (`id_receita`),
  CONSTRAINT `ItensReceita_ibfk_1` FOREIGN KEY (`id_receita`) REFERENCES `Receitas` (`id_receita`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `ModelosDocumentos` (
  `id_modelo` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `conteudo` longtext COLLATE utf8mb4_unicode_ci,
  `tipo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Geral',
  `ativo` tinyint(1) DEFAULT '1',
  `data_criacao` datetime DEFAULT CURRENT_TIMESTAMP,
  `data_atualizacao` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_modelo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `NfseEmissoes` (
  `id_emissao` int NOT NULL AUTO_INCREMENT,
  `id_fatura` int NOT NULL,
  `id_usuario_responsavel` int DEFAULT NULL,
  `data_emissao` datetime DEFAULT CURRENT_TIMESTAMP,
  `ambiente` enum('homologacao','producao') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` enum('legacy','nacional') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'legacy',
  `valor_servico` decimal(10,2) NOT NULL,
  `aliquota_iss` decimal(5,2) NOT NULL,
  `iss_retido` tinyint(1) NOT NULL,
  `item_lista_servico` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discriminacao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `numero_rps` int DEFAULT NULL,
  `serie_rps` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_dps` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_nota` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chave_nfse` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_verificacao` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_xml` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `url_pdf` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `url_visualizacao_nacional` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pendente','processando','concluido','erro','cancelado') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'pendente',
  `mensagem_erro` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `xml_envio` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `xml_retorno` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_emissao`),
  KEY `id_fatura` (`id_fatura`),
  CONSTRAINT `NfseEmissoes_ibfk_1` FOREIGN KEY (`id_fatura`) REFERENCES `Faturas` (`id_fatura`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `PacoteItens` (
  `id_item` int NOT NULL AUTO_INCREMENT,
  `id_pacote` int NOT NULL,
  `id_servico` int NOT NULL,
  `quantidade` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_item`),
  KEY `id_pacote` (`id_pacote`),
  KEY `id_servico` (`id_servico`),
  CONSTRAINT `PacoteItens_ibfk_1` FOREIGN KEY (`id_pacote`) REFERENCES `Pacotes` (`id_pacote`) ON DELETE CASCADE,
  CONSTRAINT `PacoteItens_ibfk_2` FOREIGN KEY (`id_servico`) REFERENCES `Servicos` (`id_servico`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Pacotes` (
  `id_pacote` int NOT NULL AUTO_INCREMENT,
  `nome_pacote` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `valor_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `is_recorrente` tinyint(1) NOT NULL DEFAULT '0',
  `intervalo_dias_recorrencia` int NOT NULL DEFAULT '30',
  `icone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'card_giftcard',
  `imagem_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pacote`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Pagamentos` (
  `id_pagamento` int NOT NULL AUTO_INCREMENT,
  `id_fatura` int NOT NULL,
  `valor_pago` decimal(10,2) NOT NULL,
  `data_pagamento` date NOT NULL,
  `status_pagamento` enum('Pendente','Confirmado','Cancelado','Expirado') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pendente',
  `observacao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itens_pagos_json` text COLLATE utf8mb4_unicode_ci,
  `cod_qrcode` text COLLATE utf8mb4_unicode_ci,
  `txid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `e2eid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calendario` json DEFAULT NULL,
  PRIMARY KEY (`id_pagamento`),
  UNIQUE KEY `txid` (`txid`),
  UNIQUE KEY `e2eid` (`e2eid`),
  KEY `id_fatura` (`id_fatura`),
  CONSTRAINT `Pagamentos_ibfk_1` FOREIGN KEY (`id_fatura`) REFERENCES `Faturas` (`id_fatura`)
) ENGINE=InnoDB AUTO_INCREMENT=220 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Pets` (
  `id_pet` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int NOT NULL,
  `nome` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `especie` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `raca` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sexo` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `peso` decimal(5,2) DEFAULT NULL,
  `chip_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `obs` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `data_cadastro` datetime DEFAULT CURRENT_TIMESTAMP,
  `porte` enum('P','M','G','GG') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'P',
  `tipo_pelagem` enum('Curto','Medio','Longo','Dupla Pelagem') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Curto',
  `preferencias_banho` text COLLATE utf8mb4_unicode_ci,
  `foto_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'URL pública da foto/avatar do pet no Oracle Object Storage',
  PRIMARY KEY (`id_pet`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `Pets_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `Clientes` (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `PixRecorrencias` (
  `id_pix_recorrencia` int NOT NULL AUTO_INCREMENT,
  `id_recorrencia` int NOT NULL COMMENT 'FK para Recorrencias.id_recorrencia',
  `id_cliente` int NOT NULL COMMENT 'FK para Clientes.id_cliente',
  `id_fatura_inicial` int DEFAULT NULL COMMENT 'Fatura de origem onde foi gerada a proposta Jornada 4',
  `id_rec` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ID da recorrência retornado pelo Banco Inter (ex: RN...)',
  `id_location` bigint DEFAULT NULL COMMENT 'ID da location gerada no POST /locrec',
  `txid_inicial` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'TXID da cobrança CobV vinculada no Passo 2 da Jornada 4',
  `status` enum('CRIADA','PENDENTE','APROVADA','REJEITADA','CANCELADA') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDENTE',
  `valor_recorrente` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT 'Valor mensal da recorrência',
  `data_inicial` date NOT NULL COMMENT 'Data de início da vigência do débito automático',
  `data_final` date DEFAULT NULL COMMENT 'Data final da vigência (se houver)',
  `qr_code_adesao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'String Pix Copia e Cola combinado da Jornada 4',
  `dados_bancarios_json` json DEFAULT NULL COMMENT 'Payload completo de resposta da API do Inter',
  `data_criacao` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'Data/hora de criação do registro no sistema',
  `data_aceite` datetime DEFAULT NULL COMMENT 'Data/hora de aprovação pelo pagador',
  `data_ultima_consulta` datetime DEFAULT NULL COMMENT 'Data/hora da última sincronização com o Inter',
  `motivo_cancelamento` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Motivo do cancelamento (se cancelada)',
  PRIMARY KEY (`id_pix_recorrencia`),
  UNIQUE KEY `uk_id_rec` (`id_rec`),
  KEY `idx_recorrencia` (`id_recorrencia`),
  KEY `idx_cliente` (`id_cliente`),
  KEY `idx_fatura_inicial` (`id_fatura_inicial`),
  KEY `idx_status` (`status`),
  KEY `idx_txid_inicial` (`txid_inicial`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Receitas` (
  `id_receita` int NOT NULL AUTO_INCREMENT,
  `id_atendimento` int NOT NULL,
  `data_receita` datetime DEFAULT CURRENT_TIMESTAMP,
  `observacoes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id_receita`),
  KEY `id_atendimento` (`id_atendimento`),
  CONSTRAINT `Receitas_ibfk_1` FOREIGN KEY (`id_atendimento`) REFERENCES `Atendimentos` (`id_atendimento`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Recorrencias` (
  `id_recorrencia` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int NOT NULL,
  `id_servico` int NOT NULL,
  `quantidade` int NOT NULL,
  `valor_sugerido_recorrencia` decimal(10,2) NOT NULL,
  `tipo_periodo` enum('diario','semanal','mensal','anual') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_cobranca` enum('COMERCIAL','CORTESIA','TESTE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'COMERCIAL' COMMENT 'Modalidade de faturamento: COMERCIAL (gera fatura), CORTESIA (isento) ou TESTE (trial)',
  `motivo_cortesia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Justificativa ou detalhes da concessão de cortesia ou teste',
  `intervalo` int NOT NULL,
  `dia_vencimento` tinyint DEFAULT NULL COMMENT 'Dia preferencial de vencimento da fatura (1 a 31)',
  `data_inicio_cobranca` date NOT NULL,
  `data_fim_cobranca` date DEFAULT NULL,
  `ultima_fatura_gerada_mes_ano` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_lista_servico` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aliquota_iss` decimal(5,2) DEFAULT NULL,
  `iss_retido` tinyint(1) DEFAULT NULL,
  `descricao_personalizada` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `descricao_fiscal` text COLLATE utf8mb4_unicode_ci,
  `codigo_cnae` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_tributacao_municipio` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_nbs` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_recorrencia`),
  UNIQUE KEY `id_cliente` (`id_cliente`,`id_servico`,`tipo_periodo`,`intervalo`,`data_inicio_cobranca`),
  KEY `id_servico` (`id_servico`),
  KEY `idx_recorrencias_tipo_cobranca` (`tipo_cobranca`),
  CONSTRAINT `Recorrencias_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `Clientes` (`id_cliente`),
  CONSTRAINT `Recorrencias_ibfk_2` FOREIGN KEY (`id_servico`) REFERENCES `Servicos` (`id_servico`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Servicos` (
  `id_servico` int NOT NULL AUTO_INCREMENT,
  `nome_servico` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao_fiscal` text COLLATE utf8mb4_unicode_ci,
  `valor_sugerido` decimal(10,2) NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `tipo_servico` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PADRAO' COMMENT 'PADRAO ou SAAS_INSTANCE',
  `saas_default_image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'dinovatech:latest' COMMENT 'Imagem Docker template para novos tenants',
  `saas_default_memory` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '128Mi' COMMENT 'Limite de memória padrão (ex: 128Mi)',
  `saas_default_cpu` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '250m' COMMENT 'Limite de CPU padrão (ex: 250m)',
  `item_lista_servico` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_tributacao_nacional` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_cnae` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_tributacao_municipio` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_nbs` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aliquota_iss` decimal(5,2) DEFAULT '0.00',
  `tributacao_issqn` tinyint NOT NULL DEFAULT '1',
  `iss_retido` tinyint(1) DEFAULT '0',
  `cst_ibs_cbs` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000',
  `classificacao_trib_ibs_cbs` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `indicador_operacao` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '050101',
  `descricao_nfse_padrao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `disponivel_clinica` tinyint(1) NOT NULL DEFAULT '1',
  `disponivel_banho` tinyint(1) NOT NULL DEFAULT '0',
  `duracao_minutos` int NOT NULL DEFAULT '30',
  `icone_servico` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'pets',
  `imagem_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id_servico`),
  KEY `idx_servicos_ativo` (`ativo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `TribRefCorrelacaoIbsCbs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo_trib_nac` char(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_nbs` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cst_ibs_cbs` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT '000',
  `classificacao_trib` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT '000000',
  `indicador_operacao` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT '050101',
  PRIMARY KEY (`id`),
  KEY `idx_trib_nac` (`codigo_trib_nac`),
  KEY `idx_nbs` (`codigo_nbs`)
) ENGINE=InnoDB AUTO_INCREMENT=2404 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `TribRefNbs` (
  `codigo_nbs` varchar(9) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `item_lc116_relacionado` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`codigo_nbs`),
  KEY `idx_item_lc116` (`item_lc116_relacionado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `TribRefTributacaoNacional` (
  `codigo_trib_nac` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_lc116` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci,
  `cnae_sugerido` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aliquota_padrao` decimal(5,2) DEFAULT '2.00',
  PRIMARY KEY (`codigo_trib_nac`),
  KEY `idx_item_lc116` (`item_lc116`),
  KEY `idx_cnae` (`cnae_sugerido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel_acesso` enum('admin','colaborador') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'colaborador',
  `id_colaborador` int DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_usuarios_colaborador` (`id_colaborador`),
  CONSTRAINT `fk_usuarios_colaborador` FOREIGN KEY (`id_colaborador`) REFERENCES `Veterinarios` (`id_vet`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `VacinaCiclos` (
  `id_ciclo` int NOT NULL AUTO_INCREMENT,
  `id_vacina` int NOT NULL,
  `nome` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `intervalo` int NOT NULL,
  PRIMARY KEY (`id_ciclo`),
  KEY `id_vacina` (`id_vacina`),
  CONSTRAINT `VacinaCiclos_ibfk_1` FOREIGN KEY (`id_vacina`) REFERENCES `Vacinas` (`id_vacina`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Vacinas` (
  `id_vacina` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `recorrencia_dias` int DEFAULT '365',
  PRIMARY KEY (`id_vacina`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `Veterinarios` (
  `id_vet` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `funcao` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'veterinario',
  `realiza_banho` tinyint(1) NOT NULL DEFAULT '0',
  `realiza_clinica` tinyint(1) NOT NULL DEFAULT '1',
  `crmv` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uf_crmv` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_calendar_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ID da Agenda Google do Profissional',
  `url_assinatura` text COLLATE utf8mb4_unicode_ci,
  `data_nascimento` date DEFAULT NULL,
  PRIMARY KEY (`id_vet`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `config_contadev_logs` (
  `id_log` int NOT NULL AUTO_INCREMENT,
  `id_fatura` int DEFAULT NULL,
  `acao` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('sucesso','erro','info') COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensagem` text COLLATE utf8mb4_unicode_ci,
  `payload_requisicao` longtext COLLATE utf8mb4_unicode_ci,
  `payload_resposta` longtext COLLATE utf8mb4_unicode_ci,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_log`),
  KEY `id_fatura` (`id_fatura`),
  KEY `acao` (`acao`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `migrations_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migration_name` (`migration_name`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `nf_contadev_sync` (
  `id_sync` int NOT NULL AUTO_INCREMENT,
  `id_fatura` int NOT NULL,
  `contadev_nf_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tomador_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pdf_s3_uri` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `xml_s3_uri` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `issued_at` date DEFAULT NULL,
  `status_importacao` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'pendente',
  `import_dedup_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detalhes_resposta` longtext COLLATE utf8mb4_unicode_ci,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_sync`),
  KEY `id_fatura` (`id_fatura`),
  KEY `contadev_nf_id` (`contadev_nf_id`),
  CONSTRAINT `fk_nf_contadev_sync_fatura` FOREIGN KEY (`id_fatura`) REFERENCES `Faturas` (`id_fatura`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `saas_tenant_crons` (
  `id_cron` int NOT NULL AUTO_INCREMENT,
  `id_tenant` int NOT NULL COMMENT 'Vínculo com a instância em saas_tenants',
  `nome_job` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Identificador único do Job no Kubernetes (ex: faturas-recorrentes)',
  `descricao` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Descrição legível da rotina agendada',
  `script_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Caminho do script PHP (ex: dinovatech/cron/gerar_faturas_recorrencias.php)',
  `argumentos` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Argumentos CLI adicionais opcionais',
  `cron_expression` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0 6 1 * *' COMMENT 'Expressão Crontab de agendamento',
  `ativo` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 = Ativo, 0 = Pausado',
  `ultimo_status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Último status reportado pelo cluster (RUNNING, SUCCESS, FAILED, PENDING)',
  `ultima_execucao` datetime DEFAULT NULL COMMENT 'Data/hora da última execução registrada',
  `ultimo_log` text COLLATE utf8mb4_unicode_ci COMMENT 'Resumo ou saída da última execução',
  `data_criacao` datetime DEFAULT CURRENT_TIMESTAMP,
  `data_atualizacao` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cron`),
  UNIQUE KEY `uk_tenant_job` (`id_tenant`,`nome_job`),
  KEY `idx_tenant_crons_tenant` (`id_tenant`),
  KEY `idx_tenant_crons_ativo` (`ativo`),
  CONSTRAINT `fk_saas_tenant_crons_tenant` FOREIGN KEY (`id_tenant`) REFERENCES `saas_tenants` (`id_tenant`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



CREATE TABLE `saas_tenants` (
  `id_tenant` int NOT NULL AUTO_INCREMENT,
  `id_recorrencia` int NOT NULL COMMENT 'Vínculo com o contrato/recorrência',
  `id_cliente` int NOT NULL COMMENT 'Cliente proprietário da instância',
  `slug_instancia` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Identificador único (ex: clinica-alfa)',
  `subdominio` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Subdomínio principal (ex: alfa.dinovatech.com.br)',
  `dominio_customizado` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Domínio próprio via CNAME (ex: sistema.clinicavet.com.br)',
  `namespace_k8s` varchar(63) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Namespace isolado no Kubernetes K3s',
  `db_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Nome do banco de dados isolado',
  `db_user` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Usuário do banco de dados do tenant',
  `db_password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Senha do banco de dados do tenant',
  `db_host` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Host ou IP do servidor MariaDB/MySQL do tenant',
  `db_port` int DEFAULT '3306' COMMENT 'Porta do servidor MariaDB/MySQL do tenant',
  `app_mode_vet` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 para ativar APP_MODE_VET, 0 para desativar',
  `app_master_key` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Chave de criptografia APP_MASTER_KEY dedicada do tenant',
  `custom_envs` text COLLATE utf8mb4_unicode_ci COMMENT 'Variáveis de ambiente customizadas no formato CHAVE=VALOR por linha',
  `versao_imagem` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'dinovatech:latest',
  `limite_memoria` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '128Mi',
  `limite_cpu` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '250m',
  `status_pod` enum('PENDING','RUNNING','STOPPED','SUSPENDED','ERROR') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `ultimo_erro` text COLLATE utf8mb4_unicode_ci,
  `data_criacao` datetime DEFAULT CURRENT_TIMESTAMP,
  `data_atualizacao` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tenant`),
  UNIQUE KEY `slug_instancia` (`slug_instancia`),
  UNIQUE KEY `subdominio` (`subdominio`),
  UNIQUE KEY `namespace_k8s` (`namespace_k8s`),
  KEY `idx_saas_recorrencia` (`id_recorrencia`),
  KEY `idx_saas_cliente` (`id_cliente`),
  KEY `idx_saas_status` (`status_pod`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

